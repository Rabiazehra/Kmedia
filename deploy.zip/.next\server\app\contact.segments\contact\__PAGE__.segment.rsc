1:"$Sreact.fragment"
2:I[94493,["/_next/static/chunks/17-qoxdx836ju.js","/_next/static/chunks/165t-2up-8~8r.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0str0r5nyr70c.js","/_next/static/chunks/0xkb-fioa.m8g.js"],"default"]
3:I[97367,["/_next/static/chunks/17-qoxdx836ju.js","/_next/static/chunks/165t-2up-8~8r.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0str0r5nyr70c.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","main",null,{"className":"min-h-screen overflow-x-hidden pt-24","children":["$","$L2",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/0xkb-fioa.m8g.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"RytExBwcpsSB4-bL8NqID"}
5:null
