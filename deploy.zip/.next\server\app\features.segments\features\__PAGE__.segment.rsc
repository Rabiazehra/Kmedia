1:"$Sreact.fragment"
2:I[74075,["/_next/static/chunks/17-qoxdx836ju.js","/_next/static/chunks/165t-2up-8~8r.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0str0r5nyr70c.js","/_next/static/chunks/16g155xkwpny..js"],"default"]
3:I[12506,["/_next/static/chunks/17-qoxdx836ju.js","/_next/static/chunks/165t-2up-8~8r.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0str0r5nyr70c.js","/_next/static/chunks/16g155xkwpny..js"],"default"]
4:I[97367,["/_next/static/chunks/17-qoxdx836ju.js","/_next/static/chunks/165t-2up-8~8r.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0str0r5nyr70c.js"],"OutletBoundary"]
5:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","main",null,{"className":"min-h-screen overflow-x-hidden pt-10","children":[["$","$L2",null,{}],["$","$L3",null,{}]]}],[["$","script","script-0",{"src":"/_next/static/chunks/16g155xkwpny..js","async":true}]],["$","$L4",null,{"children":["$","$5",null,{"name":"Next.MetadataOutlet","children":"$@6"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"RytExBwcpsSB4-bL8NqID"}
6:null
