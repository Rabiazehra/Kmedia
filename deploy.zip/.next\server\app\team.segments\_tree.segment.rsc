:HL["/_next/static/chunks/094c_5atwruf..css","style"]
:HL["/_next/static/media/0c8c4ded07fff55c-s.p.0wf336i9wr3zj.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/1b99372b3eaef0c8-s.p.0gx2haw2tmll8.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/de161955856a921d-s.p.04z8pihzuh7s1.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/fabcf92ba1ccea36-s.p.0lwj123ije5i..woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":20,"slots":{"children":{"name":"team","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"RytExBwcpsSB4-bL8NqID"}
