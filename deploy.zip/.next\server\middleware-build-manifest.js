globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/RytExBwcpsSB4-bL8NqID/_buildManifest.js",
    "static/RytExBwcpsSB4-bL8NqID/_ssgManifest.js",
    "static/RytExBwcpsSB4-bL8NqID/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0i614r7r~whsd.js",
    "static/chunks/08qjiehk0ptwe.js",
    "static/chunks/08aw1k4i07fih.js",
    "static/chunks/0imr3j_iy8.ac.js",
    "static/chunks/turbopack-0u-n0dgg8dxch.js"
  ]
};
