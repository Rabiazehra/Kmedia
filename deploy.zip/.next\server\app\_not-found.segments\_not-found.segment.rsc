1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/17-qoxdx836ju.js","/_next/static/chunks/165t-2up-8~8r.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0str0r5nyr70c.js"],"default"]
3:I[37457,["/_next/static/chunks/17-qoxdx836ju.js","/_next/static/chunks/165t-2up-8~8r.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0str0r5nyr70c.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"RytExBwcpsSB4-bL8NqID"}
